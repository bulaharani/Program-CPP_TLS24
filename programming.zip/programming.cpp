#include <iostream>
#include <cmath>

using namespace std;

int main (){
    int choice;
    double pH, concentration, Ka, Kb;
  
    cout << "Select the type of solution:\n";
    cout << "1. Strong Acid\n";
    cout << "2. Weak Acid\n";
    cout << "3. Strong Base\n";
    cout << "4. Weak Base\n";

    cout << "Enter your choice (1-4): ";
    cin >> choice;

    switch (choice) {
        case 1: // Strong Acid
            cout << "Enter the concentration of the strong acid (in mol/L): ";
            cin >> concentration;
            cout << "The pH of the solution is: " << -log10(concentration) << endl;
            break;

        case 2: // Weak Acid
            cout << "Enter the concentration of the weak acid (in mol/L): ";
            cin >> concentration;
            cout << "Enter the acid dissociation constant (Ka): ";
            cin >> Ka;
            cout << "The pH of the solution is: " << (-log10(sqrt(Ka * concentration))) << endl;
            break;

        case 3: // Strong Base
            cout << "Enter the concentration of the strong base (in mol/L): ";
            cin >> concentration;
            cout << "The pH of the solution is: " << (14.0 - (-log10(concentration))) << endl;
            break;

        case 4: // Weak Base
            cout << "Enter the concentration of the weak base (in mol/L): ";
            cin >> concentration;
            cout << "Enter the base dissociation constant (Kb): ";
            cin >> Kb;
            cout << "The pH of the solution is: " << (14 - (-log10(sqrt(Kb * concentration)))) << endl;
            break;

    }

    return 0;

}
